//
//  AppDelegate.h
//  SampleFileManager
//
//  Created by Nadeeshan Jayawardana on 8/30/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

