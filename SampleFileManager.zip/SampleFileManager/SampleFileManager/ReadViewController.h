//
//  ReadViewController.h
//  SampleFileManager
//
//  Created by Nadeeshan Jayawardana on 8/30/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReadViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextView *plistArrayTextTextView;
@property (strong, nonatomic) IBOutlet UITextView *plistDictionaryTextView;
@property (strong, nonatomic) IBOutlet UITextField *plistBooleanTextField;
@property (strong, nonatomic) IBOutlet UITextField *plistDataTextField;
@property (strong, nonatomic) IBOutlet UITextField *plistDateTextField;
@property (strong, nonatomic) IBOutlet UITextField *plistNumberTextField;
@property (strong, nonatomic) IBOutlet UITextField *plistStringTextField;

- (IBAction)readButtonAction:(id)sender;
- (IBAction)editButtonAction:(id)sender;

@end
