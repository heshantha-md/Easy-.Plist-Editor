//
//  ReadViewController.m
//  SampleFileManager
//
//  Created by Nadeeshan Jayawardana on 8/30/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import "ReadViewController.h"
// Import EasyPlistEditor file into class
#import "EasyPlistEditor.h"

@interface ReadViewController ()

@end

@implementation ReadViewController {
    // Initializing private variables of ReadViewController class
    NSString *plistArrayValue;
    NSDictionary *plistDictionaryValue;
    Boolean plistBooleanValue;
    NSData *plistDataValue;
    NSDate *plistDateValue;
    NSNumber *plistNumberValue;
    NSString *plistStringValue;
    EasyPlistEditor *easyPlistEditor;
}

- (void)readPlistFileValue {
    // Read Array value form .plist file
    _plistArrayTextTextView.text = [NSString stringWithFormat:@"%@",[easyPlistEditor getArrayWithKey:@"SampleArrayVariable"]];
    
    // Read Dictionary value form .plist file
    _plistDictionaryTextView.text = [NSString stringWithFormat:@"%@",[easyPlistEditor getDictionaryWithKey:@"SampleDictonaryVariable"]];
    
    // Read Boolean value form .plist file
    NSNumber *booleanNumber = [NSNumber numberWithBool:[easyPlistEditor getBooleanWithKey:@"SampleBooleanVariable"]];
    _plistBooleanTextField.text = [NSString stringWithFormat:@"%@",[booleanNumber integerValue] ? @"True" : @"False"];
    
    // Read Data value form .plist file
    _plistDataTextField.text = [NSString stringWithFormat:@"%@",[easyPlistEditor getDataWithKey:@"SampleDataVariable"]];
    
    // Read Date value form .plist file
    _plistDateTextField.text = [NSString stringWithFormat:@"%@",[easyPlistEditor getDateWithKey:@"SampleDateVariable"]];
    
    // Read Number value form .plist file
    _plistNumberTextField.text = [NSString stringWithFormat:@"%@",[easyPlistEditor getNumberWithKey:@"SampleNumberVariable"]];
    
    // Read String value form .plist file
    _plistStringTextField.text = [easyPlistEditor getStringWithKey:@"SampleStringVariable"];
}

// Implementing Read button action
- (IBAction)readButtonAction:(id)sender {
    [self readPlistFileValue];
}

// Implementing Edit button action
- (IBAction)editButtonAction:(id)sender {
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Init an object of EasyPlistEditor class
    easyPlistEditor = [[EasyPlistEditor alloc] initWithName:@"SampleService-Info"];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self readPlistFileValue];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
