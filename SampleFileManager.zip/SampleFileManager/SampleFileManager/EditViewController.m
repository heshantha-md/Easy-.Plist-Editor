//
//  EditViewController.m
//  SampleFileManager
//
//  Created by Nadeeshan Jayawardana on 8/30/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import "EditViewController.h"
#import "EasyPlistEditor.h"

@interface EditViewController ()

@end

@implementation EditViewController {
    // Initializing private variables of ReadViewController class
    NSString *plistArrayValue;
    NSDictionary *plistDictionaryValue;
    Boolean plistBooleanValue;
    NSData *plistDataValue;
    NSDate *plistDateValue;
    NSNumber *plistNumberValue;
    NSString *plistStringValue;
    EasyPlistEditor *easyPlistEditor;
}

// Implementing Update button action
- (IBAction)updateButtonAction:(id)sender {
    // NSArray Value
    NSArray *sampleValueArray = @[@"SampleValueChange_1", @"SampleValueChange_2", @"SampleValueChange_3"];
    BOOL arrayStatues = [easyPlistEditor setArray:sampleValueArray withKey:@"SampleArrayVariable"];
    if (arrayStatues) {
        NSLog(@"Array value successfully set to .plist file");
    }
    
    // NSDictonary Value
    NSMutableDictionary *SampleValueMutableDictionary = [[NSMutableDictionary alloc] init];
    [SampleValueMutableDictionary setObject:@"SampleValueChange_1" forKey:@"SampleKey_1"];
    [SampleValueMutableDictionary setObject:@"SampleValueChange_2" forKey:@"SampleKey_2"];
    [SampleValueMutableDictionary setObject:@"SampleValueChange_3" forKey:@"SampleKey_3"];
    BOOL dictionaryStatues = [easyPlistEditor setDictionary:SampleValueMutableDictionary withKey:@"SampleDictonaryVariable"];
    if (dictionaryStatues) {
        NSLog(@"Dictionary value successfully set to .plist file");
    }
    
    // Boolean Value
    BOOL booleanStatues = [easyPlistEditor setBoolean:((_plistBooleanSegmentedControl.selectedSegmentIndex > 0) ? false : true) withKey:@"SampleBooleanVariable"];
    if (booleanStatues) {
        NSLog(@"Boolean Value successfully set to .plist file");
    }
    
    // Data Value
    NSData *SampleData = [NSData dataWithBytes:(unsigned char[]){0x0F} length:1];
    BOOL dataStatues = [easyPlistEditor setData:SampleData withKey:@"SampleDataVariable"];
    if (dataStatues) {
        NSLog(@"Data Value successfully set to .plist file");
    }
    
    // Date Value
    BOOL dateStatues = [easyPlistEditor setDate:[NSDate date] withKey:@"SampleDateVariable"];
    if (dateStatues) {
        NSLog(@"Date Value successfully set to .plist file");
    }
    
    // NSNumber
    BOOL numberStatues = [easyPlistEditor setNumber:[NSNumber numberWithInt:[_plistNumberTextField.text intValue]] withKey:@"SampleNumberVariable"];
    if (numberStatues) {
        NSLog(@"Number Value successfully set to .plist file");
    }
    
    // NSString
    BOOL stringStatues = [easyPlistEditor setString:_plistStringTextField.text withKey:@"SampleStringVariable"];
    if (stringStatues) {
        NSLog(@"String Value successfully set to .plist file");
    }
    
    // Dismiss the current view controller
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Init an object of EasyPlistEditor class
    easyPlistEditor = [[EasyPlistEditor alloc] initWithName:@"SampleService-Info"];
    
    // Set Current date
    _plistDateTextField.text = [NSString stringWithFormat:@"%@",[NSDate date]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
