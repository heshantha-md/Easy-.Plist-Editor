//
//  EditViewController.h
//  SampleFileManager
//
//  Created by Nadeeshan Jayawardana on 8/30/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditViewController : UIViewController

@property (strong, nonatomic) IBOutlet UISegmentedControl *plistBooleanSegmentedControl;
@property (strong, nonatomic) IBOutlet UITextField *plistDateTextField;
@property (strong, nonatomic) IBOutlet UITextField *plistNumberTextField;
@property (strong, nonatomic) IBOutlet UITextField *plistStringTextField;

- (IBAction)updateButtonAction:(id)sender;

@end
